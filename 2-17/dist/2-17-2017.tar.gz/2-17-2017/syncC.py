import spam
str1="12343"
str2="12343"
l=spam.strcmp(str1,str2)
print(l)