from distutils.core import setup

setup(
    name='2-17',
    version='2017',
    packages=[''],
    url='',
    license='',
    author='Lee sang ho',
    author_email='',
    description=''
)
